import Router from "koa-router";
import { readdirSync, existsSync, lstatSync } from "node:fs";
import { join, relative } from "node:path";
import { jwtAuth } from "../middleware/auth";
import type { Context } from "koa";
import { metricsRegistry } from "../observability/metrics";
import {
  findDegradedDeps,
  findFatalDeps,
  probeServices,
  summarize,
  type ServiceDepStatus,
} from "../observability/service-health";
import { env } from "../config/env";

function camelToKebab(name: string): string {
  return name.replace(/[A-Z]/g, (m) => "-" + m.toLowerCase());
}

function inferMethod(name: string): "get" | "post" | "put" | "delete" {
  const lower = name.toLowerCase();
  if (lower === "login" || lower === "logout" || lower === "refresh" || lower.startsWith("add") || lower.startsWith("create") || lower.startsWith("save")) return "post";
  if (lower.startsWith("delete") || lower.startsWith("remove")) return "delete";
  if (lower.startsWith("edit") || lower.startsWith("update")) return "put";
  return "get";
}

function isIgnoredFile(name: string): boolean {
  if (name === "model.ts" || name === "model.js") return true;
  if (name.endsWith(".routes.ts") || name.endsWith(".routes.js")) return true;
  if (name.endsWith(".controller.ts") || name.endsWith(".controller.js")) return true;
  if (name.endsWith(".service.ts") || name.endsWith(".service.js")) return true;
  if (name.endsWith(".repository.ts") || name.endsWith(".repository.js")) return true;
  if (name.startsWith("excel.")) return true;
  return false;
}

/** snake_case → camelCase 递归 */
function toCamel(data: any): any {
  if (Array.isArray(data)) return data.map(toCamel);
  if (data && typeof data === "object" && !(data instanceof Date)) {
    const o: any = {};
    for (const k of Object.keys(data)) o[k.replace(/_([a-z])/g, (_, c) => c.toUpperCase())] = toCamel(data[k]);
    return o;
  }
  return data;
}

/** 包装 Router，自动 snake→camel */
function wrapCamel(r: Router): Router {
  const w = new Router();
  w.use(async (ctx, next) => { await next(); if (ctx.body && typeof ctx.body === "object") { const b: any = ctx.body; if (b.data) b.data = toCamel(b.data); if (b.rows) b.rows = toCamel(b.rows); } });
  w.use(r.routes(), r.allowedMethods());
  return w;
}

function scanAndRegister(baseDir: string, currentDir: string, apiRouter: Router): void {
  if (!existsSync(currentDir)) return;
  const entries = readdirSync(currentDir);
  const indexFile = entries.find((f) => f === "index.ts" || f === "index.js");
  const relPath = relative(baseDir, currentDir).replace(/\\/g, "/");
  const prefix = "/" + relPath;

  let hasConfig = false;

  if (indexFile) {
    try {
      const mod = require(join(currentDir, indexFile));

      // 导出 Router → 挂载自定义路由
      if (mod.default?.routes && mod.default?.allowedMethods) {
        // wrapCamel 会创建新的 Router 实例，必须只创建一次，否则 routes()/allowedMethods() 来自不同实例
        const wrapped = wrapCamel(mod.default);
        // 检查是否同时有 config（混合模式：自定义 Router + 标准 CRUD）
        const mixedCfg = mod.config ?? (mod.default?.table && mod.default?.pkField ? mod.default : null);

        if (mixedCfg?.table && mixedCfg?.pkField) {
          // 混合模式：自定义 Router 先挂载（优先匹配，覆盖特定路由）
          //           CRUD 后挂载（作为兜底，补充未覆盖的标准路由）
          apiRouter.use(wrapped.routes(), wrapped.allowedMethods());
          const { defineCrudModule } = require("./crud");
          const cr = defineCrudModule({ ...mixedCfg, prefix });
          apiRouter.use(cr.routes(), cr.allowedMethods());
          return;
        }
        // 纯自定义模式：没有 config，只挂载自定义 Router
        apiRouter.use(wrapped.routes(), wrapped.allowedMethods());
        return;
      }

      if (mod.config) hasConfig = true;
      else if (mod.default?.table && mod.default?.pkField) { mod.config = mod.default; hasConfig = true; }

      registerFunctions(prefix, mod, apiRouter);
    } catch (e: any) {
      // CRUD 配置错误必须让应用启动失败（带上模块路径），其他加载错误只告警
      if (e?.name === 'CrudConfigError') {
        throw new Error(`${prefix} 配置错误 → ${e.message}`);
      }
      console.warn(`[router] failed to load ${indexFile}:`, e.message);
    }
  }

  for (const entry of entries) {
    if (entry === "index.ts" || entry === "index.js") continue;
    if (isIgnoredFile(entry)) continue;
    if (!entry.endsWith(".ts") && !entry.endsWith(".js")) continue;
    const filePath = join(currentDir, entry);
    try {
      if (lstatSync(filePath).isDirectory()) continue;
      const mod = require(filePath);
      if (mod.default?.routes && mod.default?.allowedMethods) {
        const sr = wrapCamel(mod.default);
        apiRouter.use(prefix, sr.routes(), sr.allowedMethods());
        continue;
      }
      registerFunctions(prefix, mod, apiRouter);
    } catch (e: any) { console.warn(`[router] failed to load ${entry}:`, e.message); }
  }

  if (hasConfig && indexFile) {
    const mod = require(join(currentDir, indexFile));
    const cfg = mod.config ?? (mod.default?.table ? mod.default : null);
    if (cfg?.table && cfg?.pkField) {
      const { defineCrudModule } = require("./crud");
      const cr = defineCrudModule({ ...cfg, prefix });
      apiRouter.use(cr.routes(), cr.allowedMethods());
      return;
    }
  }

  // 子目录始终递归：允许「自身 index.ts（CRUD / 函数路由）+ 子目录（自定义 Router）」共存，
  // 例如 src/api/auth/index.ts 与 src/api/auth/captcha/index.ts。
  for (const entry of entries) {
    if (entry === "index.ts" || entry === "index.js") continue;
    const fullPath = join(currentDir, entry);
    try { if (lstatSync(fullPath).isDirectory() && !entry.startsWith(".") && !entry.startsWith("_")) scanAndRegister(baseDir, fullPath, apiRouter); } catch { /* skip */ }
  }
}

function registerFunctions(prefix: string, mod: any, apiRouter: Router): void {
  const router = new Router({ prefix });
  let count = 0;
  for (const key of Object.keys(mod)) {
    if (key === "default" || key === "config" || key === "Router") continue;
    const fn = mod[key];
    if (typeof fn !== "function") continue;
    if (/^[A-Z]/.test(key)) continue;

    const path = "/" + camelToKebab(key);
    const method = inferMethod(key);
    const noAuth = key.startsWith("public") || key.startsWith("Public") || key === "login" || key === "logout" || key === "refresh";
    const middlewares: any[] = noAuth ? [] : [jwtAuth()];
    (router as any)[method](path, ...middlewares, async (ctx: Context) => {
      const data = await fn(ctx);
      if (data !== undefined) ctx.body = { code: 200, data: toCamel(data), message: "操作成功" };
    });
    count++;
  }
  if (count > 0) apiRouter.use(router.routes(), router.allowedMethods());
}

export function createRouter(): Router {
  const router = new Router({ prefix: "/api" });
  router.get("/health", (ctx) => { ctx.body = { status: "ok" }; });
  router.get("/metrics", async (ctx) => {
    // 阶段七：生产环境默认关闭匿名 metrics（改由 /internal/metrics 提供，需服务鉴权）
    if (!env.security.metricsPublic) {
      ctx.status = 404;
      ctx.body = { code: 404, message: '接口不存在' };
      return;
    }
    ctx.set('Content-Type', metricsRegistry.contentType);
    ctx.body = await metricsRegistry.metrics();
  });

  /**
   * 就绪探针：覆盖**全部**服务依赖（MySQL / Redis / 事件服务 / AI 服务 / 图形验证码服务）。
   * - 核心依赖不可用 → 503（不要摘进负载均衡）；
   * - 非核心依赖不可用 → 200 但 degraded=true（主体可服务，功能降级）。
   * ⚠ 公开端点只回状态，**不回**内网地址与失败详情（避免泄露内网拓扑）；
   *   带地址 / 耗时 / 启动命令的详细视图在 /internal/services（内部鉴权）。
   */
  router.get("/ready", async (ctx) => {
    const results = await probeServices();
    const services: Record<string, ServiceDepStatus> = {};
    for (const r of results) services[r.name] = r.status;

    const fatal = findFatalDeps(results);
    const degraded = findDegradedDeps(results);
    ctx.status = fatal.length > 0 ? 503 : 200;
    ctx.body = {
      status: fatal.length > 0 ? "not_ready" : "ready",
      degraded: degraded.length > 0,
      checkedAt: new Date().toISOString(),
      summary: summarize(results),
      // 兼容旧结构：{ mysql: 'up', redis: 'up' }
      services,
      unavailable: results.filter((r) => r.status === "down").map((r) => r.name),
    };
  });
  scanAndRegister(join(__dirname, "..", "api"), join(__dirname, "..", "api"), router);
  return router;
}
