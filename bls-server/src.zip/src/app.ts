// ====== OpenTelemetry Tracing — 必须在所有其他 import 之前初始化 ======
// 确保 mysql2 / ioredis 等模块在被 instrumentation 插件 hook 之后才加载
import { initTracing } from './observability/tracing';
import { assertSupportedRuntime } from './core/runtime-guard';

// ====== 运行时环境守卫 — 必须最先执行 ======
// 旧版 Node 缺少 Array#toSorted / 全局 ReadableStream 等能力时，进程仍会启动监听端口，
// 但 worker / outbox 轮询会持续抛出难以定位的错误（假可用）。这里直接 fail-fast。
// 被其他模块 import（如单测）时只告警不终止进程。
assertSupportedRuntime({ exit: require.main === module });

initTracing();

import Koa from 'koa';
import http from 'http';
import helmet from 'koa-helmet';
import cors from '@koa/cors';
import koaBody from 'koa-body';
import bodyParser from 'koa-bodyparser';
import { env } from './config/env';
import { createRouter } from './core/router';
import { errorHandler } from './middleware/error-handler';
import { logger } from './core/logger';
import { tenantMiddleware } from './middleware/tenant';
import { replayProtectionMiddleware } from './middleware/replay-protection';
import { httpMetricsMiddleware } from './middleware/http-metrics';
import { requestContextMiddleware } from './core/request-context';
import { traceMiddleware } from './distributed/trace';
import { rateLimitMiddleware } from './security/rate-limit/middleware';
import { blockedIpMiddleware } from './security/event-center/ip-block-middleware';
import { apiVersion } from './middleware/api-version';
import { openApiAuth } from './middleware/openapi-auth';
import { internalAuth } from './middleware/internal-auth';
import { operationLogMiddleware } from './middleware/operation-log';
import { attachRealtimeWs } from './api/system/realtime/realtime.ws';
import { worker } from './queue/worker';
import { exportJob } from './queue/jobs/export.job';
import { importJob } from './queue/jobs/import.job';
import { notificationJob } from './queue/jobs/notification.job';
import { webhookJob } from './queue/jobs/webhook.job';
import { tenantOffboardJob } from './queue/jobs/tenant-offboard.job';
import { outboxPublisher } from './outbox/outbox-publisher';
import { registerOutboxSubscribers } from './outbox/subscribers';
import {
  findFatalDeps,
  probeServices,
  reportStartupServices,
  startServiceWatchdog,
  toServiceDetail,
} from './observability/service-health';

export function createApp(): Koa {
  const app = new Koa();

  // 可信代理：仅在 Nginx 前置时开启，Koa 信任 X-Forwarded-* Header
  if (env.trustProxy) app.proxy = true;

  const router = createRouter();

  app.use(errorHandler);
  app.use(helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        scriptSrc: ["'self'", "'unsafe-inline'", "'unsafe-eval'", "https://unpkg.com"],
        styleSrc: ["'self'", "'unsafe-inline'", "https://unpkg.com"],
        imgSrc: ["'self'", "data:", "https:"],
        connectSrc: ["'self'", "https:"],
        fontSrc: ["'self'", "data:"],
        objectSrc: ["'none'"],
        frameAncestors: ["'none'"],
      },
    },
  }));
  app.use(cors({
    credentials: true,
    origin: (ctx) => {
      const origin = ctx.get('Origin');
      if (!origin) return '';
      if (env.isProduction) {
        return env.corsOrigins.includes(origin) ? origin : '';
      }
      return env.corsOrigin === '*' ? origin : env.corsOrigin;
    },
  }));
  app.use(koaBody({ multipart: true, formidable: { multiples: false } }));
  app.use(bodyParser({ enableTypes: ['json', 'form'] }));
  app.use(traceMiddleware());
  app.use(requestContextMiddleware);
  app.use(httpMetricsMiddleware);
  app.use(tenantMiddleware);
  app.use(replayProtectionMiddleware());
  app.use(blockedIpMiddleware());
  app.use(rateLimitMiddleware());
  // 阶段五：所有写操作自动写 sys_operation_log（在安全中间件之后，避免记录被拦截的噪音）
  app.use(operationLogMiddleware());

  // ====== API Versioning ======

  // 1. 保存原始路径（后续 rewrite 后会变）
  app.use(async (ctx, next) => {
    ctx.state.originalPath = ctx.path;
    await next();
  });

  // 2. /api/v1/* → rewrite 到 /api/*（透明代理到同一套路由）
  app.use(async (ctx, next) => {
    if (ctx.path.startsWith('/api/v1/')) {
      ctx.path = '/api' + ctx.path.slice(7);
    }
    await next();
  });

  // 3. 旧 /api/* 路径 (非 /api/v1/) 返回 Deprecation/Sunset
  app.use(async (ctx, next) => {
    const orig = ctx.state.originalPath as string | undefined;
    if (orig?.startsWith('/api/') && !orig?.startsWith('/api/v1/')) {
      ctx.set('Deprecation', 'true');
      ctx.set('Sunset', new Date(Date.now() + 180 * 24 * 3600 * 1000).toISOString());
    }
    await next();
  });

  app.use(apiVersion());
  app.use(router.routes());
  app.use(router.allowedMethods());

  // ====== API 文档 (Swagger UI) ======
  const { readFileSync, existsSync } = require('node:fs');
  const { join: pathJoin } = require('node:path');
  const KoaRouter = require('koa-router');
  const docsRouter = new KoaRouter();
  docsRouter.get('/api/docs', (ctx: any) => {
    // 阶段七：生产环境默认关闭 API 文档（可用 API_DOCS_ENABLED=true 显式打开）
    if (!env.security.apiDocsEnabled) {
      ctx.status = 404;
      ctx.body = { code: 404, message: '接口不存在' };
      return;
    }
    ctx.type = 'html';
    ctx.body = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>BLS-KOX API 文档</title>
  <link rel="stylesheet" href="https://unpkg.com/swagger-ui-dist@5/swagger-ui.css" />
  <style>
    html { box-sizing: border-box; overflow-y: scroll; }
    *, *:before, *:after { box-sizing: inherit; }
    body { margin: 0; background: #fafafa; }
    .swagger-ui .topbar { background-color: #1677ff; }
    .swagger-ui .topbar .download-url-wrapper .select-label { color: #fff; }
    .swagger-ui .info .title { font-size: 24px; }
  </style>
</head>
<body>
  <div id="swagger-ui"></div>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-bundle.js" crossorigin></script>
  <script src="https://unpkg.com/swagger-ui-dist@5/swagger-ui-standalone-preset.js" crossorigin></script>
  <script>
    window.onload = () => {
      SwaggerUIBundle({
        url: '/api/openapi.json',
        dom_id: '#swagger-ui',
        deepLinking: true,
        presets: [SwaggerUIBundle.presets.apis, SwaggerUIStandalonePreset],
        layout: "StandaloneLayout",
        defaultModelsExpandDepth: -1,
        docExpansion: 'list',
        filter: true,
        tryItOutEnabled: true,
      });
    };
  </script>
</body>
</html>`;
  });
  docsRouter.get('/api/openapi.json', (ctx: any) => {
    if (!env.security.apiDocsEnabled) {
      ctx.status = 404;
      ctx.body = { code: 404, message: '接口不存在' };
      return;
    }
    const filePath = pathJoin(__dirname, '..', 'openapi.json');
    if (existsSync(filePath)) {
      ctx.type = 'json';
      ctx.body = readFileSync(filePath, 'utf-8');
    } else {
      ctx.status = 404;
      ctx.body = { error: 'openapi.json not found. Run: npm run openapi' };
    }
  });
  app.use(docsRouter.routes());

  // ====== /openapi/v1 — 独立鉴权 ======
  const openapiR = new KoaRouter({ prefix: '/openapi/v1' });
  openapiR.use(openApiAuth());
  openapiR.use(async (ctx: any, next: any) => {
    // rewrite /openapi/v1/... → /api/... 复用现有路由
    ctx.path = '/api' + ctx.path.slice(11);
    await next();
  });
  openapiR.use(router.routes());
  app.use(openapiR.routes());

  // ====== /internal — 内部服务鉴权 ======
  const internalR = new KoaRouter({ prefix: '/internal' });
  internalR.use(internalAuth());
  internalR.get('/health', (ctx: any) => { ctx.body = { status: 'ok' }; });
  /**
   * 依赖详细视图（内部鉴权）：带内网地址、耗时、失败原因与启动命令。
   * 公开的 /api/ready 只回状态，避免把内网拓扑暴露给匿名调用者。
   */
  internalR.get('/services', async (ctx: any) => {
    const detail = toServiceDetail(await probeServices());
    ctx.status = detail.status === 'ready' ? 200 : 503;
    ctx.body = detail;
  });
  internalR.get('/metrics', async (ctx: any) => {
    const { metricsRegistry } = await import('./observability/metrics.js');
    ctx.set('Content-Type', metricsRegistry.contentType);
    ctx.body = await metricsRegistry.metrics();
  });
  app.use(internalR.routes());

  // 4xx 多为可预期的业务拒绝（人机验证未通过、鉴权失败、参数校验不通过等），
  // 打成 ERROR 会造成日志噪音与误告警；只有 5xx / 未知异常才需要排查。
  app.on('error', (error) => {
    const status = typeof (error as any)?.status === 'number' ? (error as any).status : 500;
    if (status >= 500) logger.error('Unhandled application error', { error: String(error) });
    else logger.warn('Request rejected', { error: String(error) });
  });

  return app;
}

if (require.main === module) {
  // ====== 人机验证第二层（Tianai）配置检查 ======
  // `captcha_tianai_enabled=true` 时，一旦风控要求第二层而 TIANAI_BASE_URL 缺失，
  // 登录会 fail closed（HTTP 503 / 50302）—— 这是"配了验证码却没人能登录"最常见的来源，
  // 必须在启动时就明确告知运维。
  if (!(process.env.TIANAI_BASE_URL ?? '').trim()) {
    logger.warn(
      '[captcha] TIANAI_BASE_URL 未配置：第二层（Tianai 图形验证）不可用。'
      + ' 若数据库中的 captcha_tianai_enabled=true，风控要求第二层时会 fail closed（HTTP 503 / 50302）。'
      + ' 请部署 Tianai 并配置该变量，或把系统参数 captcha_tianai_enabled 置为 false（第一层 ALTCHA 仍然强制）。',
    );
  }

  // ====== 生产环境安全启动校验 ======
  if (process.env.NODE_ENV === 'production') {
    const issues: string[] = [];
    const WEAK_SECRETS = ['please_change_me', '123456', 'password', 'changeme'];
    const PLACEHOLDER_PREFIX = 'CHANGE_TO_';

    const jwt = process.env.JWT_SECRET ?? '';
    if (!jwt || WEAK_SECRETS.some(w => jwt.toLowerCase().includes(w)) || jwt.toUpperCase().startsWith(PLACEHOLDER_PREFIX)) {
      issues.push('JWT_SECRET is missing or too weak (must be >= 32 chars, no common passwords or CHANGE_TO_* placeholder)');
    }
    if (jwt.length < 32) issues.push('JWT_SECRET must be at least 32 characters');

    const dbPwd = process.env.DB_PASSWORD ?? '';
    if (!dbPwd || WEAK_SECRETS.some(w => dbPwd.toLowerCase() === w) || dbPwd.toUpperCase().startsWith(PLACEHOLDER_PREFIX)) {
      issues.push('DB_PASSWORD is missing or too weak (no CHANGE_TO_* placeholder allowed)');
    }

    const redisPwd = process.env.REDIS_PASSWORD ?? '';
    if (!redisPwd || WEAK_SECRETS.some(w => redisPwd.toLowerCase() === w) || redisPwd.toUpperCase().startsWith(PLACEHOLDER_PREFIX)) {
      issues.push('REDIS_PASSWORD is missing or too weak (no CHANGE_TO_* placeholder allowed)');
    }

    const replayEnabled = (process.env.REPLAY_ENABLED ?? 'true') === 'true';
    const apiSignSecret = process.env.API_SIGN_SECRET?.trim() ?? '';
    if (replayEnabled && apiSignSecret.toUpperCase().startsWith(PLACEHOLDER_PREFIX)) {
      issues.push('API_SIGN_SECRET must not be a CHANGE_TO_* placeholder (replay protection is enabled)');
    }

    // 登录人机验证（ALTCHA）：生产环境必须配置强 ALTCHA_HMAC_KEY，且禁止开发绕过
    const altchaHmacKey = process.env.ALTCHA_HMAC_KEY?.trim() ?? '';
    if (!altchaHmacKey) {
      issues.push('ALTCHA_HMAC_KEY is missing (required in production to sign and verify ALTCHA challenges)');
    } else {
      if (altchaHmacKey.length < 32) issues.push('ALTCHA_HMAC_KEY must be at least 32 characters');
      if (WEAK_SECRETS.some(w => altchaHmacKey.toLowerCase().includes(w)) || altchaHmacKey.toUpperCase().startsWith(PLACEHOLDER_PREFIX)) {
        issues.push('ALTCHA_HMAC_KEY is too weak (no common passwords or CHANGE_TO_* placeholder)');
      }
    }
    if ((process.env.CAPTCHA_DEV_BYPASS ?? 'false') === 'true') {
      issues.push('CAPTCHA_DEV_BYPASS=true is a development-only switch and must not be enabled in production');
    }

    if (issues.length > 0) {
      console.error('[security] Production startup blocked due to weak configuration:');
      for (const issue of issues) console.error('  - ' + issue);
      console.error('[security] Please set strong values in .env and restart.');
      process.exit(1);
    }
  }

  const app = createApp();
  const server = http.createServer(app.callback());
  const wss = attachRealtimeWs(server, app);

  /** 运行期依赖巡检定时器（Graceful Shutdown 时清理） */
  let serviceWatchdog: NodeJS.Timeout | null = null;

  // ====== 启动顺序：先 listen，再做依赖自检 ======
  // 为什么不是「先自检、再 listen」：Koa 的实时通道（bls-realtime-ws）与 HTTP **共用同一个端口**，
  // 它的 WebSocket 握手只有在该端口 listen 之后才可能成功。放在 listen 之前探测必然得到
  // ECONNREFUSED，把组件自己误报成「服务未启动」（旧实现就是这样，还在巡检里多报一次「已恢复」）。
  // 严格模式（生产默认 SERVICE_CHECK_STRICT=true）核心依赖不可用时立刻退出：端口只开了几十毫秒，
  // 这期间进来的请求本来也会因依赖不可用而失败。
  void (async () => {
    await new Promise<void>((resolve, reject) => {
      const onError = (error: Error) => reject(error);
      server.once('error', onError);
      server.listen(env.port, env.host, () => {
        // 监听成功后摘掉临时错误处理，之后的 server 错误按原行为交给进程
        server.off('error', onError);
        logger.info(`${env.appName} started`, { host: env.host, port: env.port, nodeEnv: env.nodeEnv });
        resolve();
      });
    });

    // 自检：「哪个微服务没开」必须在启动那一刻就说清楚，而不是等出错再猜：
    //   Redis 没开 → 会话 / 防重放 / 限流静默失效；event-service 没开 → 审计事件进死信；
    //   Tianai 没开 → 高风险账号登录 fail closed（503）；后端整体没起 → 前端只看到 504。
    const results = await probeServices();
    reportStartupServices(results);

    const fatal = findFatalDeps(results);
    if (fatal.length > 0) {
      const names = fatal.map((r) => `${r.name}(${r.message})`).join('、');
      if (env.serviceCheck.strict) {
        logger.error(`[services] 核心依赖不可用：${names}；SERVICE_CHECK_STRICT=true，退出启动`);
        process.exit(1);
      }
      logger.warn(`[services] 核心依赖不可用：${names}；SERVICE_CHECK_STRICT=false，继续启动（仅建议开发环境）`);
    }

    // 注册并启动 Worker
    worker.register(exportJob).register(importJob).register(notificationJob).register(webhookJob)
      .register(tenantOffboardJob).start();

    // 注册订阅者并启动 Outbox Publisher
    registerOutboxSubscribers();
    outboxPublisher.start();

    // 运行期巡检：依赖中途挂掉 / 恢复时记一条日志（只记状态变化，不刷屏）
    serviceWatchdog = startServiceWatchdog({ initial: results });
  })().catch((error) => {
    logger.error('[startup] 服务启动失败', { error: String(error) });
    process.exit(1);
  });

  // ========== DR — 定时自动备份 ==========
  const backupEnabled = (process.env.BACKUP_ENABLED ?? 'false') === 'true';
  if (backupEnabled) {
    const intervalH = parseInt(process.env.BACKUP_INTERVAL_HOURS ?? '24', 10);
    const intervalMs = Math.max(intervalH, 1) * 60 * 60 * 1000;
    logger.info('[backup] enabled', { intervalHours: intervalH });

    const runBackup = () => {
      const { exec } = require('child_process');
      const child = exec('npm run db:backup -- --compress --no-color', {
        cwd: __dirname + '/..',
        timeout: 10 * 60 * 1000,
      });
      child.stdout?.on('data', (d: Buffer) => logger.info('[backup] ' + d.toString().trim()));
      child.stderr?.on('data', (d: Buffer) => logger.warn('[backup] ' + d.toString().trim()));
      child.on('error', (err: Error) => logger.error('[backup] spawn error', { error: err.message }));
    };

    // 启动后延迟 5 分钟做首次备份（避免与启动高峰冲突）
    setTimeout(runBackup, 5 * 60 * 1000);
    setInterval(runBackup, intervalMs);
  }

  // ========== Graceful Shutdown ==========
  let shuttingDown = false;
  const SHUTDOWN_TIMEOUT = 30_000;

  /** 等待 HTTP Server 真正关闭 */
  function closeHttpServer(srv: http.Server): Promise<void> {
    return new Promise((resolve, reject) => {
      srv.close((error) => {
        if (error) reject(error);
        else resolve();
      });
    });
  }

  /** 关闭 WebSocket Server */
  async function closeWebSocketServer(ws: ReturnType<typeof attachRealtimeWs>): Promise<void> {
    if (!ws) return;
    await new Promise<void>((resolve) => {
      // 通知所有客户端关闭
      for (const client of (ws as any).clients || []) {
        try { client.close(1001, 'Server shutting down'); } catch {}
      }
      ws.close(() => resolve());
    });
  }

  async function shutdown(signal: string) {
    if (shuttingDown) return;
    shuttingDown = true;
    logger.info(`Received ${signal}, shutting down gracefully...`);

    // 超时保护：必须在 shutdown() 内启动，确保仅初始调用方持有
    const forceExit = setTimeout(() => {
      logger.error('Graceful shutdown timeout, forcing exit');
      process.exit(1);
    }, SHUTDOWN_TIMEOUT).unref();

    // 1. Stop accepting new HTTP connections
    try { await closeHttpServer(server); } catch (e) { logger.error('HTTP server close error', { error: String(e) }); }
    logger.info('[shutdown] HTTP server closed');

    // 2. Stop Worker
    try { await worker.stop(); } catch {}
    logger.info('[shutdown] Worker stopped');

    // 2b. Stop Outbox Publisher
    try { await outboxPublisher.stop(); } catch {}
    logger.info('[shutdown] Outbox Publisher stopped');

    // 2c. Stop 依赖巡检
    if (serviceWatchdog) { clearInterval(serviceWatchdog); serviceWatchdog = null; }
    logger.info('[shutdown] Service watchdog stopped');

    // 3. Close WebSocket
    try { await closeWebSocketServer(wss); } catch {}
    logger.info('[shutdown] WebSocket closed');

    // 4. Close Redis
    try {
      const { closeRedis } = require('./shared/utils/redis');
      await closeRedis();
      logger.info('[shutdown] Redis closed');
    } catch {}

    // 4. Close MySQL pools
    try {
      const { closeDatabase } = require('./core/database');
      await closeDatabase();
      logger.info('[shutdown] MySQL pools closed');
    } catch {}

    clearTimeout(forceExit);
    logger.info('[shutdown] Graceful shutdown complete');
    process.exit(0);
  }

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}
